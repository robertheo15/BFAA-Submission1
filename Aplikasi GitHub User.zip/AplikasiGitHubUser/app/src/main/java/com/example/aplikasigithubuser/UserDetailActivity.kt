package com.example.aplikasigithubuser

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.aplikasigithubuser.databinding.ActivityUserDetailBinding

class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding

    companion object {
        const val EXTRA_USER = "extra_user"
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val user = intent.getParcelableExtra<User>(EXTRA_USER) as User

        binding.textName.text = user.name.toString()
        binding.textUsername.text = "@${user.username.toString()}"
        binding.textLocation.text = "Location ${user.location.toString()}"
        binding.textRepository.text = "${user.repository.toString()} Repository"
        binding.textCompany.text = "Company ${user.company.toString()}"
        binding.textFollower.text = "${user.followers.toString()} Followers"
        binding.textFollowing.text = "${user.following.toString()} Following"
        Glide.with(binding.imageDetail.context)
            .load(user.avatar!!)
            .circleCrop()
            .into(binding.imageDetail)
    }
}